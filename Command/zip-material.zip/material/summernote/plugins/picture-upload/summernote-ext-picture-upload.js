(function(factory) {
  /* global define */
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['jquery'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // Node/CommonJS
    module.exports = factory(require('jquery'));
  } else {
    // Browser globals
    factory(window.jQuery);
  }
}(function($) {
  // Extends plugins for adding hello.
  //  - plugin is external module for customizing.
  $.extend($.summernote.plugins, {
    /**
     * @param {Object} context - context object has status of editor.
     */
    'picture-upload': function(context) {
      var self = this;
      var _url = BASE_WEB;

      // ui has renders to build ui elements.
      //  - you can create a button with `ui.button`
      var ui = $.summernote.ui;

      // add hello button
      context.memo('button.picture-upload', function() {
        // create button
        var button = ui.button({
          contents: '<i class="fa fa-child"/> Imagen',
          tooltip: 'Imagen',
          click: function() {
              self.$modal.modal('show');

            //self.$panel.show();
            //self.$panel.hide(500);
            // invoke insertText method with 'hello' on editor module.
            context.invoke('editor.insertText', 'picture-upload');
          }
        });

        // create jQuery object from button instance.
        var $hello = button.render();
        return $hello;
      });

      // This events will be attached when editor is initialized.
      this.events = {
        // This will be called after modules are initialized.
        'summernote.init': function(we, e) {
          console.log('summernote initialized', we, e);
        },
        // This will be called when user releases a key on editable.
        'summernote.keyup': function(we, e) {
          console.log('summernote keyup', we, e);
        }
      };

      // This method will be called when editor is initialized by $('..').summernote();
      // You can create elements for plugin
      this.initialize = function() {
        this.$panel = $('<div class="hello-panel"/>').css({
          position: 'absolute',
          width: 100,
          height: 100,
          left: '50%',
          top: '50%',
          background: 'red'
        }).hide();

        this.$panel.appendTo('body');
        if($(".summernote-insert-image-modal").length == 0){
            this.$modal = $("<div class='summernote-insert-image-modal modal hide fade'><div class='modal-dialog' role='document'><div class='modal-content'>" +
                "<div class='modal-header'>" +
                "<a class='close' data-dismiss='modal'>&times;</a>" +
                "<h3>" + + "</h3>" +
                "</div>" +
                "<div class='modal-body'>" +
                "<div class='chooser_wrapper'>" +
                "<table class='image_chooser images'></table>" +
                "<h4>Or Upload one to insert</h4>" +
                "<form method='post' enctype='multipart/form-data' id='frm-summernote-insert-image'><input name=\"file\" id=\"summernote-insert-image-file1\" type=\"file\"></form>" +
                "<div id=\"uploadresult\"></div>" +
                "</div>" +
                "</div>" +
                "<div class='modal-footer'>" +
                "<a href='#' class='btn' data-dismiss='modal'>Cancelar</a>" +
                "</div>" +
                "</div></div></div>").hide();
            this.$modal.appendTo('body');
            this.iniInputFileChange();
        }else{
            this.$modal = $(".summernote-insert-image-modal");
        }

      };
      this.iniInputFileChange = function (){

          $('#summernote-insert-image-file1').on('change',function() {
              console.log(_url+'assets/material/summernote/api/index.php');
              var formData = new FormData(document.getElementById("frm-summernote-insert-image"));
              $.ajax({
                  url : _url+'assets/material/summernote/api/index.php',
                  type : 'POST',
                  data : formData,
                  processData: false,  // tell jQuery not to process the data
                  contentType: false,
                  success : function(resp){
                      /*if(res.status)
                       {
                       $('#summernote-insert-image-file1').val('');
                       chooser.append(optionTemplate({"file":res.file,"caption":res.caption}));
                       $('#uploadresult').html('Upload successful').addClass('alert alert-success');
                       }
                       else
                       {
                       $('#uploadresult').html('Upload failed').addClass('alert alert-error');
                       }*/
                  }
              });
              /*$(this).parent()[0].submit(function (event) {
                  event.preventDefault();

                  return false;
              });*/
          });
        };


      // This methods will be called when editor is destroyed by $('..').summernote('destroy');
      // You should remove elements on `initialize`.
      this.destroy = function() {
        this.$panel.remove();
        this.$panel = null;
      };
    }
  });
}));
