(function (factory) {
    /* global define */
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['jquery'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // Node/CommonJS
        module.exports = factory(require('jquery'));
    } else {
        // Browser globals
        factory(window.jQuery);
    }
}(function ($) {
    // Extends plugins for adding hello.
    //  - plugin is external module for customizing.
    $.extend($.summernote.plugins, {
        /**
         * @param {Object} context - context object has status of editor.
         */
        'picture-upload': function (context) {
            var self = this;
            var _url = SUMMERNOTE_UPLOAD;

            // ui has renders to build ui elements.
            //  - you can create a button with `ui.button`
            var ui = $.summernote.ui;
            var $editor = context.layoutInfo.editor;
            var options = context.options;

            var listImages = [];

            // add hello button
            context.memo('button.picture-upload', function () {
                return ui.button({
                    contents: '<i class="note-icon-picture">',
                    tooltip: 'Imagen',
                    click: function () {
                        self.updateListImages();
                        self.show();
                    }
                }).render();
            });

            // This events will be attached when editor is initialized.
            this.events = {
                // This will be called after modules are initialized.
                'summernote.init': function (we, e) {
                    //console.log('summernote initialized', we, e);
                },
                // This will be called when user releases a key on editable.
                'summernote.keyup': function (we, e) {
                    //console.log('summernote keyup', we, e);
                }
            };

            // This method will be called when editor is initialized by $('..').summernote();
            // You can create elements for plugin
            this.initialize = function () {
                var $container = options.dialogsInBody ? $(document.body) : $editor;

                var body = '<div class="chooser_wrapper"><div class="chooser_wrapper_list"></div>'+
                    "<h4>O sube una diferente</h4>" +
                    '<form method="post" enctype="multipart/form-data" id="frm-summernote-insert-image">' +
                    '<label for="summernote-insert-image-file1" class="btn btn-primary">Selecciona una imagen<input name="file" id="summernote-insert-image-file1" type="file"></label></form>' +
                    '<div id="uploadresult"></div>' +
                    '</div>';

                this.$dialog = ui.dialog({
                    title: 'Selecciona la imagen', /*lang.specialChar.select,*/
                    body: body
                }).render().appendTo($container);
            };

            this.show = function () {
                var text = context.invoke('editor.getSelectedText');
                context.invoke('editor.saveRange');
                this.updateListImages().then(function (select){
                    self.showImageUploadDialog(text).then(function (selectChar) {
                        context.invoke('editor.restoreRange');

                        // build node
                        var $node = $('<span></span>').html(selectChar)[0];

                        if ($node) {
                            // insert video node
                            context.invoke('editor.insertNode', $node);
                        }
                    }).fail(function () {
                        context.invoke('editor.restoreRange');
                    });
                }).fail(function () {
                    context.invoke('editor.restoreRange');
                });

            };
            /**
             * Make Div List Images
             *
             * @member plugin.picture-upload
             * @private
             * @return {jQuery}
             */
            this.makeListImagesDiv = function () {
                var $div = $('<div class="choose_images_list row"></div>');
                $div.html('');

                $.each(listImages, function (idx, item) {
                    var $divnode = $('<div class="col-sm-2" style="margin-bottom: 5px;"></div>').addClass('node-imageuploaded_node');
                    var $button = ui.button({
                        callback: function ($node) {
                            $node.html('<img src="' + item[0] + '" class="itemlistimages"  /><span>'+item[1]+'</span>');
                            $node.attr('title', 'Insertar');
                            $node.attr('data-value', (item[0]));
                        }
                    }).render();

                    $divnode.append($button);
                    $div.append($divnode)
                });

                return $div;
            };

            this.updateListImages = function () {
                return $.Deferred(function (deferred) {
                    var xhr = $.ajax({
                        url: _url,
                        type: 'GET',
                        data: null,
                        datatype: 'json',
                        processData: false,  // tell jQuery not to process the data
                        contentType: false,
                        success: function (res) {
                            listImages = res.lista;
                            deferred.resolve();
                        },
                        error: function (request, status, error) {
                            if (deferred.state() === 'pending') {
                                deferred.reject();
                            }
                        }
                    });
                });

            };

            // This methods will be called when editor is destroyed by $('..').summernote('destroy');
            // You should remove elements on `initialize`.
            this.destroy = function () {
                this.$panel.remove();
                this.$panel = null;
            };

            /**
             * show image dialog
             *
             * @param {jQuery} $dialog
             * @return {Promise}
             */
            this.showImageUploadDialog = function (text) {
                return $.Deferred(function (deferred) {
                    var $specialCharDialog = self.$dialog;

                    var wrapperlist = self.$dialog.find('.chooser_wrapper_list');
                    wrapperlist.html('');
                    self.makeListImagesDiv().appendTo(wrapperlist);

                    var inputfile = self.$dialog.find('#summernote-insert-image-file1');
                    var uploadresult = self.$dialog.find('#uploadresult');

                    var $specialCharNode = $specialCharDialog.find('.node-imageuploaded_node');
                    var $selectedNode = null;

                    ui.onDialogShown(self.$dialog, function () {
                        //self.$dialog.find('button').tooltip();

                        $specialCharNode.on('click', function (event) {
                            event.preventDefault();
                            deferred.resolve('<img src="'+$(event.currentTarget).find('button').attr('data-value')+'"/>');
                            ui.hideDialog(self.$dialog);
                        });
                        inputfile.on('change',function(event){
                            var formData = new FormData(document.getElementById("frm-summernote-insert-image"));
                            $.ajax({
                                url: _url,
                                type: 'POST',
                                data: formData,
                                processData: false,  // tell jQuery not to process the data
                                contentType: false,
                                success: function (resp) {
                                    if (resp.subido) {
                                        inputfile.val('');
                                        $specialCharNode.off('click');
                                        listImages = resp.lista;
                                        wrapperlist.html('');
                                        self.makeListImagesDiv().appendTo(wrapperlist);
                                        $specialCharNode = $specialCharDialog.find('.node-imageuploaded_node');
                                        $specialCharNode.on('click', function (event) {
                                            event.preventDefault();
                                            deferred.resolve('<img src="'+$(event.currentTarget).find('button').attr('data-value')+'"/>');
                                            ui.hideDialog(self.$dialog);
                                        });
                                        uploadresult.html('Upload successful').addClass('alert alert-success');
                                    } else {
                                        uploadresult.html('Upload failed').addClass('alert alert-error');
                                    }
                                }
                            });
                        });
                    });

                    ui.onDialogHidden(self.$dialog, function () {
                        $specialCharNode.off('click');
                        inputfile.off('change');
                        //self.$dialog.find('button').tooltip('destroy');

                        if (deferred.state() === 'pending') {
                            deferred.reject();
                        }
                    });

                    ui.showDialog(self.$dialog);
                });
            };
        }
    });
}));
