<?php
$dir_subida = str_replace('admin/assets/material/summernote/plugins/picture-upload/api','',__DIR__).'img/';

if(!file_exists($dir_subida)){
    mkdir($dir_subida,0777,true);
}
$subido= false;
$mensaje = 'lista';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $fichero_subido = $dir_subida . rand(10,99).'_'.basename($_FILES['file']['name']);
    $subido = move_uploaded_file($_FILES['file']['tmp_name'], $fichero_subido);
    $mensaje = $subido ? 'archivo subido':'Error al escribir '.$fichero_subido;
}
$lista = [];
$url = str_replace('/admin/assets/material/summernote/plugins/picture-upload/api/index.php','',$_SERVER['REQUEST_URI']);

foreach (scandir($dir_subida) as $fichero){
    if (is_file($dir_subida.$fichero) && strpos($fichero,'.DS_') === false){
        $img = getimagesize($dir_subida.$fichero);
        $lista[] =  [$url.'/img/'.$fichero,$img[0].' x '.$img[1]];
    }
}
header('Content-Type: application/json');
echo json_encode(['subido'=>$subido,'mensaje'=>$mensaje,'lista'=>$lista]);
